﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SalonKrasoty.Services
{
    public static class BookingService
    {
        public static List<TimeSpan> GetFreeSlots(int masterId, DateTime date)
        {
            using (var db = new user20_dbEntities())
            {
                var all = new List<TimeSpan>();
                for (var t = new TimeSpan(9, 0, 0); t < new TimeSpan(21, 0, 0); t = t.Add(TimeSpan.FromMinutes(30)))
                    all.Add(t);

                var taken = db.KURS_Zapisi
                    .Where(z => z.Kod_mastera == masterId && z.Data == date.Date && z.Kod_statusa != 3)
                    .Select(z => z.Vremya)
                    .ToHashSet();

                return all.Where(t => !taken.Contains(t)).ToList();
            }
        }

        public static string Create(int clientId, int masterId, int serviceId, DateTime date, TimeSpan time)
        {
            using (var db = new user20_dbEntities())
            {
                if (date.Date < DateTime.Today) return "Нельзя записаться на прошедшую дату.";

                var busy = db.KURS_Zapisi.Any(z => z.Kod_mastera == masterId && z.Data == date.Date && z.Vremya == time && z.Kod_statusa != 3);
                if (busy) return "Это время у мастера уже занято.";

                db.KURS_Zapisi.Add(new KURS_Zapisi
                {
                    Kod_klienta = clientId,
                    Kod_mastera = masterId,
                    Kod_uslugi = serviceId,
                    Data = date.Date,
                    Vremya = time,
                    Kod_statusa = 1,
                    Data_sozdaniya = DateTime.Now
                });
                db.SaveChanges();
                return null;
            }
        }
    }
}