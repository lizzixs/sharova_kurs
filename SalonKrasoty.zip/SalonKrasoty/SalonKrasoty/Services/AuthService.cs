﻿using BCrypt.Net; // Важно для работы с паролями
using System.Data.Entity;
using System.Linq;
using System.Windows;

namespace SalonKrasoty.Services
{
    public static class AuthService
    {
        public static KURS_Users CurrentUser { get; private set; }
        public static string CurrentRole { get; private set; } = "";

        public static bool Login(string login, string password)
        {
            using (var db = new user20_dbEntities())
            {
                // 1. Ищем пользователя
                var user = db.KURS_Users.FirstOrDefault(u => u.Login == login);

                if (user == null)
                {
                    MessageBox.Show($"Пользователь с логином '{login}' не найден в БД!\nПроверьте, нет ли лишних пробелов.", "Ошибка БД");
                    return false;
                }

                // 2. Проверяем пароль
                if (!BCrypt.Net.BCrypt.Verify(password, user.Parol))
                {
                    MessageBox.Show($"Пароль не подходит!\n\nВы ввели: '{password}'\nВ базе лежит хеш: '{user.Parol}'", "Ошибка пароля");
                    return false;
                }

                // 3. Определяем роль
                CurrentUser = user;
                var role = db.KURS_Roli.FirstOrDefault(r => r.Kod_roli == user.Kod_roli);
                if (role == null)
                {
                    MessageBox.Show($"У пользователя указан Kod_roli = {user.Kod_roli}, но такой роли нет в таблице KURS_Roli!", "Ошибка роли");
                    return false;
                }

                CurrentRole = role.Nazvanie;
                return true;
            }
        }

        public static void Logout()
        {
            CurrentUser = null;
            CurrentRole = "";
        }
    }
}