﻿using System.Linq;
using System.Windows;
using SalonKrasoty.Services;

namespace SalonKrasoty.Views
{
    public partial class MainClientWindow : Window
    {
        public MainClientWindow()
        {
            InitializeComponent();
            using (var db = new user20_dbEntities())
            {
                var fio = db.KURS_Klienty.FirstOrDefault(k => k.Kod_klienta == AuthService.CurrentUser.Kod_klienta)?.FIO ?? "клиент";
                TbHello.Text = $"Здравствуйте, {fio}!";
            }
        }

        private void BtnCatalog_Click(object sender, RoutedEventArgs e) => new CatalogWindow().ShowDialog();

        private void BtnMyAppointments_Click(object sender, RoutedEventArgs e) => new MyAppointmentsWindow().ShowDialog();

        // Обработчик новой кнопки
        private void BtnAbout_Click(object sender, RoutedEventArgs e) => new AboutSalonWindow().ShowDialog();

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            AuthService.Logout();
            new LoginWindow().Show();
            Close();
        }
    }
}