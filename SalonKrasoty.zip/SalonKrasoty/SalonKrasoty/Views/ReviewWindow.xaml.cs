﻿using System;
using System.Linq;
using System.Windows;
using SalonKrasoty.Services;

namespace SalonKrasoty.Views
{
    public partial class ReviewWindow : Window
    {
        private int _zapisId;

        // Передаем ID записи из окна "Мои записи"
        public ReviewWindow(int zapisId, string serviceName, string masterName)
        {
            InitializeComponent();
            _zapisId = zapisId;
            TbInfo.Text = $"Услуга: {serviceName}\nМастер: {masterName}";
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            TbError.Text = "";
            if (string.IsNullOrWhiteSpace(TbText.Text))
            {
                TbError.Text = "Пожалуйста, напишите текст отзыва.";
                return;
            }

            // Получаем оценку от 1 до 5 (берем первый символ из строки "5 - Отлично")
            int rating = int.Parse(CbRating.SelectedItem.ToString().Substring(0, 1));

            using (var db = new user20_dbEntities())
            {
                // Проверяем, не оставлял ли уже клиент отзыв на эту запись
                if (db.KURS_Otzyvy.Any(o => o.Kod_zapisi == _zapisId))
                {
                    TbError.Text = "Вы уже оставили отзыв на эту запись.";
                    return;
                }

                var review = new KURS_Otzyvy
                {
                    Kod_zapisi = _zapisId,
                    Kod_klienta = AuthService.CurrentUser.Kod_klienta.Value,
                    Ocenka = rating,
                    Tekst = TbText.Text,
                    Data_sozdaniya = DateTime.Now
                };

                db.KURS_Otzyvy.Add(review);
                db.SaveChanges();
            }

            MessageBox.Show("Спасибо за ваш отзыв!", "Успех");
            Close();
        }
    }
}