﻿using System.Windows;
using SalonKrasoty.Services;

namespace SalonKrasoty.Views
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            TbError.Text = "";
            if (string.IsNullOrWhiteSpace(TbLogin.Text) || string.IsNullOrWhiteSpace(PbParol.Password))
            {
                TbError.Text = "Введите логин и пароль.";
                return;
            }

            if (!AuthService.Login(TbLogin.Text.Trim(), PbParol.Password))
            {
                TbError.Text = "Неверный логин или пароль.";
                return;
            }

            // Классическая конструкция вместо switch
            Window next;
            if (AuthService.CurrentRole == "Администратор")
            {
                next = new AdminWindow();
            }
            else if (AuthService.CurrentRole == "Мастер")
            {
                next = new MasterScheduleWindow();
            }
            else
            {
                next = new MainClientWindow();
            }

            next.Show();
            Close();
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            new RegisterWindow().ShowDialog();
        }
    }
}