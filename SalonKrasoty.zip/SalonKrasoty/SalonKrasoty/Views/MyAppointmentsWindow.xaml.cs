﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using SalonKrasoty.Services;

namespace SalonKrasoty.Views
{
    public partial class MyAppointmentsWindow : Window
    {
        public MyAppointmentsWindow()
        {
            InitializeComponent();
            Reload();
        }

        private void Reload()
        {
            using (var db = new user20_dbEntities())
            {
                DgZapisi.ItemsSource = db.KURS_Zapisi
                    .Include("KURS_Mastera").Include("KURS_Uslugi").Include("KURS_Statusy")
                    .Where(z => z.Kod_klienta == AuthService.CurrentUser.Kod_klienta)
                    .OrderByDescending(z => z.Data).ToList();
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button)?.DataContext is KURS_Zapisi z)
            {
                if (MessageBox.Show("Вы уверены, что хотите отменить эту запись?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    using (var db = new user20_dbEntities())
                    {
                        var item = db.KURS_Zapisi.Find(z.Kod_zapisi);
                        if (item != null)
                        {
                            if (item.Data.Date < DateTime.Today)
                            {
                                MessageBox.Show("Нельзя отменить запись на прошедшую дату.");
                                return;
                            }
                            item.Kod_statusa = 3; // Отменена
                            db.SaveChanges();
                        }
                    }
                    Reload();
                }
            }
        }

        // ОБРАБОТЧИК КНОПКИ ОТЗЫВА
        private void BtnReview_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button)?.DataContext is KURS_Zapisi z)
            {
                new ReviewWindow(z.Kod_zapisi, z.KURS_Uslugi.Nazvanie, z.KURS_Mastera.FIO).ShowDialog();
            }
        }
    }
}