﻿using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using BCrypt.Net;

namespace SalonKrasoty.Views
{
    public partial class RegisterWindow : Window
    {
        public RegisterWindow()
        {
            InitializeComponent();
        }

        private void BtnReg_Click(object sender, RoutedEventArgs e)
        {
            TbError.Text = "";

            // Проверяем, что все обязательные поля заполнены
            if (string.IsNullOrWhiteSpace(TbFio.Text) ||
                string.IsNullOrWhiteSpace(TbPhone.Text) ||
                string.IsNullOrWhiteSpace(TbEmail.Text) ||
                string.IsNullOrWhiteSpace(TbLogin.Text) ||
                string.IsNullOrWhiteSpace(PbPass.Password))
            {
                TbError.Text = "Пожалуйста, заполните все поля.";
                return;
            }

            // Проверка формата телефона
            if (!Regex.IsMatch(TbPhone.Text, @"^\+7\d{10}$"))
            {
                TbError.Text = "Телефон должен быть в формате +7XXXXXXXXXX";
                return;
            }

            // Проверка формата email (базовая)
            if (!Regex.IsMatch(TbEmail.Text, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                TbError.Text = "Введите корректный Email.";
                return;
            }

            using (var db = new user20_dbEntities())
            {
                // Проверка на уникальность логина
                if (db.KURS_Users.Any(u => u.Login == TbLogin.Text))
                {
                    TbError.Text = "Пользователь с таким логином уже существует.";
                    return;
                }

                // Создаем карточку клиента с новыми полями
                var klient = new KURS_Klienty
                {
                    FIO = TbFio.Text,
                    Telefon = TbPhone.Text,
                    Email = TbEmail.Text,
                    Data_rozhdeniya = DpBirthDate.SelectedDate // DatePicker вернет null, если дата не выбрана
                };
                db.KURS_Klienty.Add(klient);
                db.SaveChanges();

                // Создаем пользователя с захешированным паролем
                var user = new KURS_Users
                {
                    Login = TbLogin.Text,
                    Parol = BCrypt.Net.BCrypt.HashPassword(PbPass.Password),
                    Kod_roli = 1, // Роль "Клиент"
                    Kod_klienta = klient.Kod_klienta // Связываем с созданной карточкой
                };
                db.KURS_Users.Add(user);
                db.SaveChanges();
            }

            MessageBox.Show("Аккаунт успешно создан! Теперь вы можете войти.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            Close();
        }
    }
}