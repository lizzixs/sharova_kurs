﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using SalonKrasoty.Services;

namespace SalonKrasoty.Views
{
    public partial class BookingWindow : Window
    {
        private readonly KURS_Uslugi _usluga;

        public BookingWindow(KURS_Uslugi u)
        {
            InitializeComponent();
            _usluga = u;
            TbUsluga.Text = $"{u.Nazvanie} — {u.Cena:N0} ₽";
            DpDate.SelectedDate = DateTime.Today.AddDays(1);
            using (var db = new user20_dbEntities()) CbMaster.ItemsSource = db.KURS_Mastera.ToList();
        }

        private void CbMaster_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ReloadSlots();
        }

        private void DpDate_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            ReloadSlots();
        }

        private void ReloadSlots()
        {
            if (CbMaster.SelectedItem is KURS_Mastera m && DpDate.SelectedDate is DateTime d)
            {
                LbSlots.ItemsSource = BookingService.GetFreeSlots(m.Kod_mastera, d);
            }
        }

        private void BtnBook_Click(object sender, RoutedEventArgs e)
        {
            TbError.Text = "";

            if (!(CbMaster.SelectedItem is KURS_Mastera m) ||
                !(DpDate.SelectedDate is DateTime d) ||
                !(LbSlots.SelectedItem is TimeSpan t))
            {
                TbError.Text = "Выберите мастера, дату и время.";
                return;
            }

            var err = BookingService.Create(AuthService.CurrentUser.Kod_klienta.Value, m.Kod_mastera, _usluga.Kod_uslugi, d, t);
            if (err != null)
                TbError.Text = err;
            else
            {
                MessageBox.Show("Вы записаны!");
                Close();
            }
        }
    }
}