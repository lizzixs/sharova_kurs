﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using SalonKrasoty.Services;

namespace SalonKrasoty.Views
{
    public partial class MasterScheduleWindow : Window
    {
        private int _currentMasterId;

        public MasterScheduleWindow()
        {
            InitializeComponent();

            using (var db = new user20_dbEntities())
            {
                // Находим мастера по логину текущего пользователя
                var login = AuthService.CurrentUser.Login;
                var master = db.KURS_Mastera.FirstOrDefault(m => m.FIO.ToLower().Contains(login.ToLower()));

                if (master == null)
                {
                    // Если не нашли по имени, берем первого для теста
                    master = db.KURS_Mastera.FirstOrDefault();
                }

                if (master != null)
                {
                    _currentMasterId = master.Kod_mastera;
                    TbMasterName.Text = $"Мастер: {master.FIO} ({master.Specializaciya})";
                }
            }
            Reload();
        }

        private void Reload()
        {
            using (var db = new user20_dbEntities())
            {
                var schedule = db.KURS_Zapisi
                    .Include("KURS_Klienty").Include("KURS_Uslugi").Include("KURS_Statusy")
                    .Where(z => z.Kod_mastera == _currentMasterId)
                    .OrderBy(z => z.Data).ThenBy(z => z.Vremya)
                    .ToList();

                Dg.ItemsSource = schedule;

                var todayCount = schedule.Count(z => z.Data.Date == DateTime.Today);
                TbTodayStats.Text = $"📅 Записей на сегодня: {todayCount}  |  Всего в базе: {schedule.Count}";
            }
        }

        private void BtnDone_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button)?.DataContext is KURS_Zapisi z)
            {
                using (var db = new user20_dbEntities())
                {
                    var item = db.KURS_Zapisi.Find(z.Kod_zapisi);
                    if (item != null)
                    {
                        item.Kod_statusa = 2; // Выполнена
                        db.SaveChanges();
                    }
                }
                Reload();
            }
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            AuthService.Logout();
            new LoginWindow().Show();
            Close();
        }
    }
}