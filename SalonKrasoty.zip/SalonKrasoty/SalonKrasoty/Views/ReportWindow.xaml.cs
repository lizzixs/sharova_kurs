﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Windows;

namespace SalonKrasoty.Views
{
    public partial class ReportWindow : Window
    {
        public ReportWindow()
        {
            InitializeComponent();
            DpFrom.SelectedDate = DateTime.Today.AddDays(-30);
            DpTo.SelectedDate = DateTime.Today;
        }

        private void BtnBuild_Click(object sender, RoutedEventArgs e)
        {
            if (!(DpFrom.SelectedDate is DateTime f) || !(DpTo.SelectedDate is DateTime t)) return;

            using (var db = new user20_dbEntities())
            {
                var data = db.KURS_Zapisi
                    .Include(z => z.KURS_Mastera).Include(z => z.KURS_Uslugi)
                    .Where(z => z.Kod_statusa == 2 && z.Data >= f && z.Data <= t)
                    .ToList()
                    .GroupBy(z => z.KURS_Mastera.FIO)
                    .Select(g => new { Master = g.Key, Count = g.Count(), Sum = g.Sum(x => x.KURS_Uslugi.Cena) })
                    .OrderByDescending(x => x.Sum)
                    .ToList();

                Dg.ItemsSource = data;
                TbTotal.Text = $"Итого: {data.Sum(x => x.Sum):N0} ₽";
            }
        }
    }
}