﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace SalonKrasoty.Views
{
    public partial class CatalogWindow : Window
    {
        public CatalogWindow()
        {
            InitializeComponent();
            using (var db = new user20_dbEntities())
            {
                var list = db.KURS_Kategorii.ToList();
                list.Insert(0, new KURS_Kategorii { Kod_kategorii = 0, Nazvanie = "Все категории" });
                CbCategory.ItemsSource = list;
                CbCategory.SelectedIndex = 0;
            }
        }

        private void CbCategory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!(CbCategory.SelectedItem is KURS_Kategorii cat)) return;

            using (var db = new user20_dbEntities())
            {
                if (cat.Kod_kategorii == 0)
                    DgUslugi.ItemsSource = db.KURS_Uslugi.ToList();
                else
                    DgUslugi.ItemsSource = db.KURS_Uslugi.Where(u => u.Kod_kategorii == cat.Kod_kategorii).ToList();
            }
        }

        private void BtnBook_Click(object sender, RoutedEventArgs e)
        {
            var btn = sender as Button;
            if (btn != null && btn.DataContext is KURS_Uslugi u)
            {
                new BookingWindow(u).ShowDialog();
            }
        }
    }
}