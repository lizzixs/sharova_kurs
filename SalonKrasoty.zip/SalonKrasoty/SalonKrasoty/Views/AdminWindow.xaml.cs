﻿using System;
using System.Linq;
using System.Windows;
using SalonKrasoty.Services;

namespace SalonKrasoty.Views
{
    public partial class AdminWindow : Window
    {
        public AdminWindow()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            using (var db = new user20_dbEntities())
            {
                // Загружаем услуги с категориями
                DgAdminServices.ItemsSource = db.KURS_Uslugi.Include("KURS_Kategorii").ToList();
                // Загружаем мастеров
                DgAdminMasters.ItemsSource = db.KURS_Mastera.ToList();
                // Загружаем категории в выпадающий список
                CbNewServiceCategory.ItemsSource = db.KURS_Kategorii.ToList();
            }
        }

        private void BtnAddService_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(TbNewServiceName.Text) || CbNewServiceCategory.SelectedItem == null)
                { MessageBox.Show("Заполните название и выберите категорию."); return; }

                using (var db = new user20_dbEntities())
                {
                    var newService = new KURS_Uslugi
                    {
                        Nazvanie = TbNewServiceName.Text,
                        Cena = decimal.Parse(TbNewServicePrice.Text),
                        Dlitelnost = int.Parse(TbNewServiceDuration.Text),
                        Kod_kategorii = ((KURS_Kategorii)CbNewServiceCategory.SelectedItem).Kod_kategorii
                    };
                    db.KURS_Uslugi.Add(newService);
                    db.SaveChanges();
                }
                MessageBox.Show("Услуга добавлена!");
                LoadData(); // Обновляем таблицу
            }
            catch { MessageBox.Show("Проверьте правильность ввода цены и длительности."); }
        }

        private void BtnAddMaster_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TbNewMasterFio.Text)) return;

            using (var db = new user20_dbEntities())
            {
                var newMaster = new KURS_Mastera
                {
                    FIO = TbNewMasterFio.Text,
                    Specializaciya = TbNewMasterSpec.Text,
                    Telefon = TbNewMasterPhone.Text
                };
                db.KURS_Mastera.Add(newMaster);
                db.SaveChanges();
            }
            MessageBox.Show("Мастер добавлен!");
            LoadData();
        }

        private void BtnReports_Click(object sender, RoutedEventArgs e)
        {
            new ReportWindow().ShowDialog();
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            AuthService.Logout();
            new LoginWindow().Show();
            Close();
        }
    }
}