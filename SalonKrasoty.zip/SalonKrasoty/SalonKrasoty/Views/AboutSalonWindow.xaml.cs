﻿using System.Windows;

namespace SalonKrasoty.Views
{
    public partial class AboutSalonWindow : Window
    {
        public AboutSalonWindow()
        {
            InitializeComponent();
        }
    }
}