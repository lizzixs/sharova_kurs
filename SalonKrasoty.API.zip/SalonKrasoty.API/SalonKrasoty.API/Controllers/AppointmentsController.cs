﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SalonKrasoty.API.Models;

namespace SalonKrasoty.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AppointmentsController : ControllerBase
    {
        private readonly User20DbContext _context;

        public AppointmentsController(User20DbContext context)
        {
            _context = context;
        }

        public class CreateAppointmentDto
        {
            public int ClientId { get; set; }
            public int MasterId { get; set; }
            public int ServiceId { get; set; }
            public DateTime Date { get; set; }
            public TimeSpan Time { get; set; }
        }

        [HttpPost]
        public async Task<IActionResult> CreateAppointment([FromBody] CreateAppointmentDto dto)
        {
            // Конвертируем DateTime и TimeSpan в DateOnly и TimeOnly для базы данных
            var dateOnly = DateOnly.FromDateTime(dto.Date);
            var timeOnly = TimeOnly.FromTimeSpan(dto.Time);

            // Проверяем, не занято ли это время
            var exists = await _context.KursZapisis.AnyAsync(z =>
                z.KodMastera == dto.MasterId &&
                z.Data == dateOnly &&   // Сравниваем DateOnly с DateOnly
                z.Vremya == timeOnly && // Сравниваем TimeOnly с TimeOnly
                z.KodStatusa != 3);

            if (exists)
            {
                return Conflict(new { error = "Это время у мастера уже занято", code = "TIME_ALREADY_BOOKED" });
            }

            // Создаем новую запись
            var newZapis = new KursZapisi
            {
                KodKlienta = dto.ClientId,
                KodMastera = dto.MasterId,
                KodUslugi = dto.ServiceId,
                Data = dateOnly,     // Сохраняем DateOnly
                Vremya = timeOnly,   // Сохраняем TimeOnly
                KodStatusa = 1,
                DataSozdaniya = DateTime.Now
            };

            _context.KursZapisis.Add(newZapis);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Запись успешно создана", id = newZapis.KodZapisi });
        }
    }
}