﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SalonKrasoty.API.Models;

namespace SalonKrasoty.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ServicesController : ControllerBase
    {
        private readonly User20DbContext _context;

        public ServicesController(User20DbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetServices()
        {
            // Обратите внимание: в вашем контексте таблица услуг называется KursUslugi
            var services = await _context.KursUslugis.ToListAsync();
            return Ok(services);
        }
    }
}