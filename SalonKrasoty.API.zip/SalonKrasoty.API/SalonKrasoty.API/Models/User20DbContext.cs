﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace SalonKrasoty.API.Models;

public partial class User20DbContext : DbContext
{
    public User20DbContext()
    {
    }

    public User20DbContext(DbContextOptions<User20DbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<KursKategorii> KursKategoriis { get; set; }
    public virtual DbSet<KursKlienty> KursKlienties { get; set; }
    public virtual DbSet<KursMastera> KursMasteras { get; set; }
    public virtual DbSet<KursOtzyvy> KursOtzyvies { get; set; }
    public virtual DbSet<KursRoli> KursRolis { get; set; }
    public virtual DbSet<KursStatusy> KursStatusies { get; set; }
    public virtual DbSet<KursUser> KursUsers { get; set; }
    public virtual DbSet<KursUslugi> KursUslugis { get; set; }
    public virtual DbSet<KursZapisi> KursZapisis { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("Server=stud-mssql.sttec.yar.ru,38325;Database=user20_db;User Id=user20_db;Password=user20;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.UseCollation("Cyrillic_General_CI_AS");

        modelBuilder.Entity<KursKategorii>(entity =>
        {
            entity.HasKey(e => e.KodKategorii).HasName("PK__KURS_Kat__E8E8C23BBE3BA485");
            entity.ToTable("KURS_Kategorii");
            entity.HasIndex(e => e.Nazvanie, "UQ__KURS_Kat__C5571E6E949B4A9F").IsUnique();
            entity.Property(e => e.KodKategorii).HasColumnName("Kod_kategorii");
            entity.Property(e => e.Nazvanie).HasMaxLength(100);
        });

        modelBuilder.Entity<KursKlienty>(entity =>
        {
            entity.HasKey(e => e.KodKlienta).HasName("PK__KURS_Kli__8A204F4BAE046D14");
            entity.ToTable("KURS_Klienty");
            entity.Property(e => e.KodKlienta).HasColumnName("Kod_klienta");
            entity.Property(e => e.DataRozhdeniya).HasColumnName("Data_rozhdeniya");
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.Fio).HasMaxLength(150).HasColumnName("FIO");
            entity.Property(e => e.Telefon).HasMaxLength(20);
        });

        modelBuilder.Entity<KursMastera>(entity =>
        {
            entity.HasKey(e => e.KodMastera).HasName("PK__KURS_Mas__A9DA992947114B15");
            entity.ToTable("KURS_Mastera");
            entity.Property(e => e.KodMastera).HasColumnName("Kod_mastera");
            entity.Property(e => e.Fio).HasMaxLength(150).HasColumnName("FIO");
            entity.Property(e => e.Specializaciya).HasMaxLength(100);
            entity.Property(e => e.Telefon).HasMaxLength(20);
        });

        modelBuilder.Entity<KursOtzyvy>(entity =>
        {
            entity.HasKey(e => e.KodOtzyva).HasName("PK__KURS_Otz__3DF500E1EB2FFD2E");
            entity.ToTable("KURS_Otzyvy");
            entity.Property(e => e.KodOtzyva).HasColumnName("Kod_otzyva");
            entity.Property(e => e.DataSozdaniya).HasDefaultValueSql("(getdate())").HasColumnType("datetime").HasColumnName("Data_sozdaniya");
            entity.Property(e => e.KodKlienta).HasColumnName("Kod_klienta");
            entity.Property(e => e.KodZapisi).HasColumnName("Kod_zapisi");

            entity.HasOne(d => d.KodKlientaNavigation).WithMany(p => p.KursOtzyvies)
                .HasForeignKey(d => d.KodKlienta)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Otzyvy_Klienty");

            entity.HasOne(d => d.KodZapisiNavigation).WithMany(p => p.KursOtzyvies)
                .HasForeignKey(d => d.KodZapisi)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Otzyvy_Zapisi");
        });

        modelBuilder.Entity<KursRoli>(entity =>
        {
            entity.HasKey(e => e.KodRoli).HasName("PK__KURS_Rol__F968E47F210DA6B8");
            entity.ToTable("KURS_Roli");
            entity.HasIndex(e => e.Nazvanie, "UQ__KURS_Rol__C5571E6E716635E5").IsUnique();
            entity.Property(e => e.KodRoli).HasColumnName("Kod_roli");
            entity.Property(e => e.Nazvanie).HasMaxLength(50);
        });

        modelBuilder.Entity<KursStatusy>(entity =>
        {
            entity.HasKey(e => e.KodStatusa).HasName("PK__KURS_Sta__3924AAC7B0AAFBF4");
            entity.ToTable("KURS_Statusy");
            entity.HasIndex(e => e.Nazvanie, "UQ__KURS_Sta__C5571E6E70ED5FD3").IsUnique();
            entity.Property(e => e.KodStatusa).HasColumnName("Kod_statusa");
            entity.Property(e => e.Nazvanie).HasMaxLength(50);
        });

        modelBuilder.Entity<KursUser>(entity =>
        {
            entity.HasKey(e => e.KodUser).HasName("PK__KURS_Use__1F99BF7EA2A3FF34");
            entity.ToTable("KURS_Users");
            entity.HasIndex(e => e.Login, "UQ__KURS_Use__5E55825B9DC56879").IsUnique();
            entity.Property(e => e.KodUser).HasColumnName("Kod_user");
            entity.Property(e => e.KodKlienta).HasColumnName("Kod_klienta");
            entity.Property(e => e.KodRoli).HasColumnName("Kod_roli");
            entity.Property(e => e.Login).HasMaxLength(50);
            entity.Property(e => e.Parol).HasMaxLength(255);

            entity.HasOne(d => d.KodKlientaNavigation).WithMany(p => p.KursUsers)
                .HasForeignKey(d => d.KodKlienta)
                .HasConstraintName("FK_Users_Klienta");

            entity.HasOne(d => d.KodRoliNavigation).WithMany(p => p.KursUsers)
                .HasForeignKey(d => d.KodRoli)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Users_Roli");
        });

        modelBuilder.Entity<KursUslugi>(entity =>
        {
            entity.HasKey(e => e.KodUslugi).HasName("PK__KURS_Usl__315178C2C9F45E36");
            entity.ToTable("KURS_Uslugi");
            entity.Property(e => e.KodUslugi).HasColumnName("Kod_uslugi");
            entity.Property(e => e.Cena).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.KodKategorii).HasColumnName("Kod_kategorii");
            entity.Property(e => e.Nazvanie).HasMaxLength(150);

            entity.HasOne(d => d.KodKategoriiNavigation).WithMany(p => p.KursUslugis)
                .HasForeignKey(d => d.KodKategorii)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Uslugi_Kategorii");
        });

        modelBuilder.Entity<KursZapisi>(entity =>
        {
            entity.HasKey(e => e.KodZapisi).HasName("PK__KURS_Zap__656C9120F94B5CE7");
            entity.ToTable("KURS_Zapisi");
            entity.HasIndex(e => new { e.KodMastera, e.Data, e.Vremya }, "UQ_Zapisi_Master_Time").IsUnique();
            entity.Property(e => e.KodZapisi).HasColumnName("Kod_zapisi");
            entity.Property(e => e.DataSozdaniya).HasDefaultValueSql("(getdate())").HasColumnType("datetime").HasColumnName("Data_sozdaniya");
            entity.Property(e => e.KodKlienta).HasColumnName("Kod_klienta");
            entity.Property(e => e.KodMastera).HasColumnName("Kod_mastera");
            entity.Property(e => e.KodStatusa).HasDefaultValue(1).HasColumnName("Kod_statusa");
            entity.Property(e => e.KodUslugi).HasColumnName("Kod_uslugi");

            entity.HasOne(d => d.KodKlientaNavigation).WithMany(p => p.KursZapisis)
                .HasForeignKey(d => d.KodKlienta)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Zapisi_Klienta");

            entity.HasOne(d => d.KodMasteraNavigation).WithMany(p => p.KursZapisis)
                .HasForeignKey(d => d.KodMastera)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Zapisi_Mastera");

            entity.HasOne(d => d.KodStatusaNavigation).WithMany(p => p.KursZapisis)
                .HasForeignKey(d => d.KodStatusa)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Zapisi_Statusa");

            entity.HasOne(d => d.KodUslugiNavigation).WithMany(p => p.KursZapisis)
                .HasForeignKey(d => d.KodUslugi)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Zapisi_Uslugi");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}