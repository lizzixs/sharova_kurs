﻿using System;
using System.Collections.Generic;

namespace SalonKrasoty.API.Models;

public partial class KursUslugi
{
    public int KodUslugi { get; set; }

    public string Nazvanie { get; set; } = null!;

    public decimal Cena { get; set; }

    public int Dlitelnost { get; set; }

    public int KodKategorii { get; set; }

    public virtual KursKategorii KodKategoriiNavigation { get; set; } = null!;

    public virtual ICollection<KursZapisi> KursZapisis { get; set; } = new List<KursZapisi>();
}
