﻿using System;
using System.Collections.Generic;

namespace SalonKrasoty.API.Models;

public partial class KursUser
{
    public int KodUser { get; set; }

    public string Login { get; set; } = null!;

    public string Parol { get; set; } = null!;

    public int KodRoli { get; set; }

    public int? KodKlienta { get; set; }

    public virtual KursKlienty? KodKlientaNavigation { get; set; }

    public virtual KursRoli KodRoliNavigation { get; set; } = null!;
}
