﻿using System;
using System.Collections.Generic;

namespace SalonKrasoty.API.Models;

public partial class KursRoli
{
    public int KodRoli { get; set; }

    public string Nazvanie { get; set; } = null!;

    public virtual ICollection<KursUser> KursUsers { get; set; } = new List<KursUser>();
}
