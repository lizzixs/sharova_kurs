﻿using System;
using System.Collections.Generic;

namespace SalonKrasoty.API.Models;

public partial class KursStatusy
{
    public int KodStatusa { get; set; }

    public string Nazvanie { get; set; } = null!;

    public virtual ICollection<KursZapisi> KursZapisis { get; set; } = new List<KursZapisi>();
}
