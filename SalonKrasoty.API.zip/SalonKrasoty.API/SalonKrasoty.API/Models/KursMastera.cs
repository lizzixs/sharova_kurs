﻿using System;
using System.Collections.Generic;

namespace SalonKrasoty.API.Models;

public partial class KursMastera
{
    public int KodMastera { get; set; }

    public string Fio { get; set; } = null!;

    public string Specializaciya { get; set; } = null!;

    public string Telefon { get; set; } = null!;

    public virtual ICollection<KursZapisi> KursZapisis { get; set; } = new List<KursZapisi>();
}
