﻿using System;
using System.Collections.Generic;

namespace SalonKrasoty.API.Models;

public partial class KursKlienty
{
    public int KodKlienta { get; set; }

    public string Fio { get; set; } = null!;

    public string Telefon { get; set; } = null!;

    public string? Email { get; set; }

    public DateOnly? DataRozhdeniya { get; set; }

    public virtual ICollection<KursOtzyvy> KursOtzyvies { get; set; } = new List<KursOtzyvy>();

    public virtual ICollection<KursUser> KursUsers { get; set; } = new List<KursUser>();

    public virtual ICollection<KursZapisi> KursZapisis { get; set; } = new List<KursZapisi>();
}
