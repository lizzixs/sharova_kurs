﻿using System;
using System.Collections.Generic;

namespace SalonKrasoty.API.Models;

public partial class KursOtzyvy
{
    public int KodOtzyva { get; set; }

    public int KodZapisi { get; set; }

    public int KodKlienta { get; set; }

    public int Ocenka { get; set; }

    public string Tekst { get; set; } = null!;

    public DateTime DataSozdaniya { get; set; }

    public virtual KursKlienty KodKlientaNavigation { get; set; } = null!;

    public virtual KursZapisi KodZapisiNavigation { get; set; } = null!;
}
