﻿using System;
using System.Collections.Generic;

namespace SalonKrasoty.API.Models;

public partial class KursKategorii
{
    public int KodKategorii { get; set; }

    public string Nazvanie { get; set; } = null!;

    public virtual ICollection<KursUslugi> KursUslugis { get; set; } = new List<KursUslugi>();
}
