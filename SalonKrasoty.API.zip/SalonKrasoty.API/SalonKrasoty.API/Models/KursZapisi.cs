﻿using System;
using System.Collections.Generic;

namespace SalonKrasoty.API.Models;

public partial class KursZapisi
{
    public int KodZapisi { get; set; }

    public int KodKlienta { get; set; }

    public int KodMastera { get; set; }

    public int KodUslugi { get; set; }

    public DateOnly Data { get; set; }

    public TimeOnly Vremya { get; set; }

    public int KodStatusa { get; set; }

    public DateTime DataSozdaniya { get; set; }

    public virtual KursKlienty KodKlientaNavigation { get; set; } = null!;

    public virtual KursMastera KodMasteraNavigation { get; set; } = null!;

    public virtual KursStatusy KodStatusaNavigation { get; set; } = null!;

    public virtual KursUslugi KodUslugiNavigation { get; set; } = null!;

    public virtual ICollection<KursOtzyvy> KursOtzyvies { get; set; } = new List<KursOtzyvy>();
}
